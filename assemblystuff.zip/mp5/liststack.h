; liststack.h by Douglas W. Jones -- linked list stack interface
; an implementation of class stack using a linked list 
; each subclass of stack provides a constructor.

	EXT	NEWLISTSTACK
			; given   nothing
			; returns R3 -- pointer to a new list stack instance
			; may use R4-R7

; the remainder of the interface definition is found in stack.h
; nothing is revealed here about the internal details of the implementation
